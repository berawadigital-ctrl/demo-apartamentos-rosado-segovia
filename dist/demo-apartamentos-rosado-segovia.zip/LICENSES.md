# Licencias de los activos

| Activo | Origen | Autor | Licencia |
|---|---|---|---|
| img/hero.webp (+ hero-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `arches`, semilla 6611) | Berawa Solutions | Propia (generada por script) |
| img/intro.webp (+ intro-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `columns`, semilla 6612) | Berawa Solutions | Propia (generada por script) |
| img/r1.webp (+ r1-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `arches`, semilla 6621) | Berawa Solutions | Propia (generada por script) |
| img/r2.webp (+ r2-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `skyline`, semilla 6622) | Berawa Solutions | Propia (generada por script) |
| img/g1.webp (+ g1-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `hills`, semilla 6631) | Berawa Solutions | Propia (generada por script) |
| img/g2.webp (+ g2-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `waves`, semilla 6632) | Berawa Solutions | Propia (generada por script) |
| img/g3.webp (+ g3-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `columns`, semilla 6633) | Berawa Solutions | Propia (generada por script) |
| img/g4.webp (+ g4-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `arches`, semilla 6634) | Berawa Solutions | Propia (generada por script) |
| fonts/cormorant.woff2 | https://github.com/CatharsisFonts/Cormorant | Christian Thalmann (Catharsis Fonts) | SIL OFL 1.1 |

Ninguna imagen es una foto ni muestra el establecimiento: son ilustraciones propias y se rotulan «Imagen ilustrativa». Detalle por fichero (hash, parámetros de generación) en `berawa/asset_manifest.json` y `berawa/evidence/assets/`.

Los textos proceden de la web pública del negocio (apartamentosrosado.es, leída el 02/11/2026; ver `berawa/sources.json`); no se han copiado sus fotos, logotipos, vídeos ni testimonios.
